int main() {
	printf ("Hello LF!\n");
}
