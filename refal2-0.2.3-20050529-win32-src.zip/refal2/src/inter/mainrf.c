/*----------- file -- MAINRF.C -------------------*/
/*          Standard REFAL-initiator              */
/*       Last modification : 05.04.2005 (BLF)     */
/*------------------------------------------------*/

/* BLF GO -> go */
extern char go();

void main() {
  rfexec(go);
}

/*---------  end of file MAINRF.C  ---------*/
